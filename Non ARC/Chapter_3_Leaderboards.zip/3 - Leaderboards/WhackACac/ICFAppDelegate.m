//
//  ICFAppDelegate.m
//  WhackACac
//
//  Created by Kyle Richter on 7/2/12.
//  Copyright (c) 2012 Dragon Forged Software. All rights reserved.
//

#import "ICFAppDelegate.h"

#import "ICFViewController.h"

@implementation ICFAppDelegate

@synthesize window = _window;
@synthesize navController = _navController;
@synthesize viewController = _viewController;

- (void)dealloc
{
    [_window release];
    [_navController release];
    [_viewController release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];

    self.viewController = [[[ICFViewController alloc] initWithNibName:@"ICFViewController" bundle:nil] autorelease];
    
    self.navController = [[UINavigationController alloc] initWithRootViewController:self.viewController];
    
    [self.navController setNavigationBarHidden: YES];
    
    self.window.rootViewController = self.navController
    ;
    [self.window makeKeyAndVisible];
    return YES;
}


@end
